package com.example.bank.controller;

import com.example.bank.model.Bank;
import com.example.bank.service.BankService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
public class BankController {
 @Autowired
    BankService service;
    @PostMapping( value = "/saveStd" ,consumes = MediaType.APPLICATION_JSON_VALUE ,produces = MediaType.APPLICATION_JSON_VALUE )
    public ResponseEntity<Bank> print(@RequestBody Bank std)
    {
        service.store(std);
        return new ResponseEntity<Bank>(std, HttpStatus.CREATED);
    }

    @GetMapping( value = "/Banks" ,produces = MediaType.APPLICATION_JSON_VALUE )
    public ResponseEntity<List<Bank>> getStds()
    {
        List<Bank> list=service.getBanks();
        return new ResponseEntity<List<Bank>>(list,HttpStatus.CREATED);
    }

    @GetMapping( value = "/Student/{id}" ,produces = MediaType.APPLICATION_JSON_VALUE )
    public ResponseEntity<Bank> getStd(@PathVariable("id") int id)
    {
        Bank std=service.getBanks(id);
        return new ResponseEntity<Bank>(std,HttpStatus.CREATED);
    }

    @PutMapping( value = "/Student" ,produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Bank> updateStd(@RequestBody Bank std)
    {
        service.store(std);
        return new ResponseEntity<Bank>(std,HttpStatus.CREATED);
    }

    @DeleteMapping( value = "/delete/{id}" ,consumes = MediaType.APPLICATION_JSON_VALUE )
    public ResponseEntity<String> deleteStudent(@PathVariable("id") int id)
    {
        service.deleteStd(id);
        return new ResponseEntity<String>("recored deleted",HttpStatus.CREATED);
    }
}
