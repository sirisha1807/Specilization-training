package com.example.bank.service;

import com.example.bank.model.Bank;
import com.example.bank.repo.BankRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BankService {
@Autowired
    BankRepo repo;
    public void store(Bank std) {
        repo.save(std);
    }
    public  List<Bank> getBanks(){
        List<Bank> list=repo.findAll();
        return list;
    }

    public Bank getBanks(int id) {

        Bank std=repo.findById(id).orElse(new Bank());

        return std;
    }

    public void deleteStd(int id) {
        repo.deleteById(id);
    }
}
