
import './App.css';
import '../node_modules/bootstrap/dist/css/bootstrap.min.css'
import NavbarComp from './components/NavbarComp';
import Home from './components/Home'
import Cart from './components/Cart';
import {CartProvider} from 'react-use-cart';
import About from './components/About';
import Login from './components/login';
import {
    BrowserRouter as Router,
    Switch,
    Route,
    Link
  } from "react-router-dom";

function App() {
  return (
    
    <div>
    <CartProvider>
        <NavbarComp/>
        {/* <Home/>
        <Cart> </Cart> */}
        </CartProvider>
        {/* <Login></Login> */}

        
   </div>
  );
}

export default App;
