import React, { Component } from "react";
 // import { Button, Form, FormControl } from "react-bootstrap";
import { Navbar,Nav,NavDropdown,Form,FormControl,Button} from "react-bootstrap";
import {
    BrowserRouter as Router,
    Switch,
    Route,
    Link
  } from "react-router-dom";
import About from "./About";
import Contact from "./Contact";
import Home from "./Home";
import Login from "./login";
import Register from "./Register";
import Profile from "./Profile";
import Cart  from './Cart'
  

export default class NavbarComp extends Component{
    render(){
        return(
            <Router>
            <div>
                <Navbar bg="dark" variant={"dark"} expand="lg">
    <Navbar.Brand as={Link} to={'/Home'}>Jet-Pens</Navbar.Brand>
    <Navbar.Toggle aria-controls="basic-navbar-nav" />
    <Navbar.Collapse id="basic-navbar-nav">
      <Nav className="me-auto">
      
        <Nav.Link as={Link} to={'/Home'}>Home</Nav.Link>

        <Nav.Link as={Link} to={'/About'}>About</Nav.Link>

        <Nav.Link as={Link} to={'/Contact'}>Contact</Nav.Link>

        <NavDropdown title="Dropdown" id="basic-nav-dropdown">

          <NavDropdown.Item as={Link} to={"/Login"}>Login</NavDropdown.Item>

          <NavDropdown.Item  as={Link} to={"/Register"}>Register</NavDropdown.Item>

          <NavDropdown.Item as={Link} to={"/profile"}>Profile</NavDropdown.Item>
          <NavDropdown.Divider />
          <NavDropdown.Item as={Link} to={'/Cart'}>Cart</NavDropdown.Item>
        </NavDropdown>
      </Nav>
      <Form inline>
          <FormControl type="text" placeholder="Search" className="mr-sm-2" />
          <Button variant="outline-success"> Search </Button>
      </Form>
    </Navbar.Collapse>
</Navbar>
   </div>
    <div>
      <Switch> 

          <Switch>
              <Route exact path='/Home' component={Home} />
              <Route exact path='/About' component={About} />
              <Route exact path='/Contact' component={Contact} />
              <Route exact path='/Login'  component={Login}/>
              <Route exact path='/Register' component={Register} />
               <Route exact path='/Profile' component={Profile} />
               <Route exact path='/Cart' component={Cart} />
        </Switch>
          </Switch>
    </div>
   </Router> 
        );
    }
}