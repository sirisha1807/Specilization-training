import React, { Component } from "react";



class Register extends Component{

    render(){
        return(
            <div >
                <div className="Login">
                    <h1>Register</h1>
                    <input type="text" placeholder="userName" /><br />
                    <br />
                    <input type="text" placeholder="Mobile" /><br />
                    <br />
                    <input type="text" placeholder="email" /><br />
                    <br />
                    <input type="text" placeholder="password" /><br />
                    <br />
                    <input type="text" placeholder="Address" /><br /><br />
            
                    <button> Register</button>

                </div>
            </div>
        )
    }
}

export default Register;