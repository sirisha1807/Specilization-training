import img1 from './img/img1.png';
import img2 from './img/img2.png';
import img3 from './img/img3.png';
import img4 from './img/img4.png';
import img5 from './img/img5.png';
import img7 from './img/img7.png';
import img8 from './img/img8.png';
import img9 from './img/img9.png';

const data={
    productData:[
        {
            id:1,
            img:img1,
            title:"blackpen",
            desc:'',
            price:45,
        },
        {
            id:2,
            img:img2,
            title:"pen Pencil",
            desc:'',
            price:50,
        },
        {
            id:3,
            img:img3,
            title:"ink pen",
            desc:'',
            price:100,
        },
        {
            id:4,
            img:img4,
            title:"Gel pen",
            desc:'',
            price:80,
        },
        {
            id:5,
            img:img5,
            title:"Roller Bollpen",
            desc:'',
            price:90,
        },
        {
            id:6,
            img:img7,
            title:" USB pen",
            desc:'',
            price:300,
        },
        {
            id:7,
            img:img8,
            title:" Blue pen",
            desc:'',
            price:450,  
        },
        {
            id:8,
            img:img9,
            title:" LED pen",
            desc:'',
            price:450,    
        }
    ],
}

export default data;