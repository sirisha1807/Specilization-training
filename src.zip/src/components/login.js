import React, { Component } from "react";

class Login extends Component{

    render(){
        return(
            <div >
                <div className="Login">
                    <h1>Login</h1>
                    <input type="text" placeholder="email" /><br />
                    <br />
                    <input type="text" placeholder="password" /><br />
                    <br />
                    <button> Login</button>

                </div>
            </div>
        )
    }
}

export default Login;