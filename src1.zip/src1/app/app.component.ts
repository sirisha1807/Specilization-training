import { Component } from '@angular/core';
import { BankService } from './bank.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'bank';
  employees:any=[];
  constructor(private bankservice:BankService){}
  ngOnInit(): void {
    this.bankservice.getAllEmp().subscribe((data)=>{
      this.employees=data;
      console.log(data);
    })
  }
}
