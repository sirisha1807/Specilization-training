import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Bank } from './bank';

@Injectable({
  providedIn: 'root'
})
export class BankService {
  private _URL:string="http://localhost:8080"
  constructor( private http:HttpClient) { }
saveEmp( bank:Bank):Observable<Bank>
{
 return this.http.post<Bank>(`${this._URL}/saveStd`,bank);
}
getAllEmp():Observable<Bank[]>{
  return this.http.get<Bank[]>(`${this._URL}/Banks`);
}
}
