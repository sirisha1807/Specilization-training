export class Bank{
    saveEmp(bank: Bank) {
      throw new Error('Method not implemented.');
    }
    id:number=1;
    name:string=" ";
    mobile:String=" ";
    email:string=" ";
    account:string=" ";
    actype:string=" ";
    password:any;
    

}



