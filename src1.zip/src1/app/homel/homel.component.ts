import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-homel',
  templateUrl: './homel.component.html',
  styleUrls: ['./homel.component.css']
})
export class HomelComponent implements OnInit {
  val: any;
  val1: any;
  constructor() { }

  ngOnInit(): void {
  }
  demo(v:any, v1:any){
    this.val=(v*v1*0.07);
  }

  demo1(v:any, v1:any){
    this.val1=(v*v1*0.04);
  }

}
