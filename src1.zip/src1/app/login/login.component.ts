import { Component, OnInit } from '@angular/core';
import { Bank } from '../bank';
import { BankService } from '../bank.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
bank = new Bank;
valid:boolean=true;
prop:string="";

  constructor(private bankservice:BankService) { }

  ngOnInit(): void {
  }
  loginuser(){
    
  }


}
