import { Component, OnInit } from '@angular/core';
import { Bank } from '../bank';
import { BankService } from '../bank.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
bank:Bank=new Bank();
  constructor(private bankservice:BankService) { }

  ngOnInit(): void {
  }
save(obj:any){
  this.bank.id=obj.id;
 this.bank.name=obj.name;
 this.bank.account=obj.account;
 this.bank.actype=obj.actype;
 this.bank.email=obj.email;
 this.bank.mobile=obj.mobile;
 this.bank.password=obj.password;
 if(this.bank !==null){
  this.bankservice.saveEmp(this.bank).subscribe((res)=>{
    console.log(res);
  });

 }
}

}
